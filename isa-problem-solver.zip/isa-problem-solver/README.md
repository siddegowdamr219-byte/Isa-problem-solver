# ISA Problem Solver (COA)

A beginner-friendly full-stack learning website for Instruction Set Architecture concepts.

## Features

- ISA overview and study notes
- Binary, decimal and hexadecimal converter
- Addressing mode calculator
- Small educational instruction simulator (ADD, SUB, MUL, AND, OR, XOR, LOAD, INC)
- Simplified 16-bit instruction format encoder
- Practice quiz with score and explanations
- Responsive layout for phones and computers

## Technology

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js and Express
- API: JSON over HTTP

## Run on a computer

1. Install Node.js 18 or later.
2. Open a terminal in this project folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000` in a browser.

## Run from an Android phone

A code editor alone can preview static HTML, but this project has a Node.js backend. To run the complete full-stack app on a phone, use a cloud coding environment that supports Node.js (for example, Replit) or deploy the repository to a Node.js hosting service. GitHub stores the source code; it does not run the Express server by itself.

## Deploy

You can deploy this Node.js project to a service that supports Node web apps:

- Build command: `npm install`
- Start command: `npm start`
- Runtime: Node.js 18+

After deployment, open the URL supplied by the hosting service.

## Important academic note

The 16-bit instruction encoder uses a simplified teaching format:
`opcode (4) | destination (3) | source 1 (3) | source 2 (3) | function (3)`

This is a demonstration format, not a real ARM, RISC-V or x86 instruction encoding. Addressing mode formulas and instruction behavior can vary by ISA. Match the format taught in your syllabus.

## Project structure

```text
isa-problem-solver/
├── package.json
├── server.js
├── README.md
├── .gitignore
└── public/
    ├── index.html
    ├── style.css
    └── app.js
```
